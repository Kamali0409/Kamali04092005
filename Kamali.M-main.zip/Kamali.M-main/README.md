<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My First Web Page</title>
</head>
<body>

    <h1>Welcome to My Website</h1>
    <p>This is a simple web page using HTML.</p>

    <h2>My Interests</h2>
    <ul>
        <li>Web Development</li>
        <li>Graphic Design</li>
        <li>Photography</li>
    </ul>

    <h2>Contact Me</h2>
    <p>Email: example@email.com</p>

</body>
</html>

Explanation:

<h1> to <h2> → Used for headings (larger to smaller size).

<p> → Paragraph text.

<ul> & <li> → Unordered list with bullet points.

<meta> → Helps with responsiveness and character encoding.


Do you need a specific HTML page, like a form or a portfolio?

